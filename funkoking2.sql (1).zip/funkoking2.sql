-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 21 jun 2020 om 22:13
-- Serverversie: 5.7.28
-- PHP-versie: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `funkoking2`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `addresses`
--

DROP TABLE IF EXISTS `addresses`;
CREATE TABLE IF NOT EXISTS `addresses` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `street` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postalcode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postbox` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `addresses`
--

INSERT INTO `addresses` (`id`, `user_id`, `street`, `city`, `number`, `country`, `postalcode`, `postbox`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Moerput', 'Geluwe', '103', 'Belgie', '8940', 'NULL', '2020-06-21 05:20:59', '2020-06-21 05:20:59', NULL),
(2, 2, 'Dourdanstraat', 'Geluwe', '9', 'Belgie', '8940', 'NULL', '2020-06-21 15:58:55', '2020-06-21 15:58:55', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `blog_category_id` int(11) NOT NULL,
  `photo_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogs_user_id_index` (`user_id`),
  KEY `blogs_blog_category_id_index` (`blog_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blogs`
--

INSERT INTO `blogs` (`id`, `user_id`, `blog_category_id`, `photo_id`, `title`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(2, 1, 1, '22', 'Sportwereld op zijn kop', 'sportwereld-op-zijn-kop', 'Het is al geruime tijd een bekend gegeven dat een lezer, tijdens het bekijken van de layout van een pagina, afgeleid wordt door de tekstuele inhoud. Het belangrijke punt van het gebruik van Lorem Ipsum is dat het uit een min of meer normale verdeling van letters bestaat, in tegenstelling tot \"Hier uw tekst, hier uw tekst\" wat het tot min of meer leesbaar nederlands maakt. Veel desktop publishing pakketten en web pagina editors gebruiken tegenwoordig Lorem Ipsum als hun standaard model tekst, en een zoekopdracht naar \"lorem ipsum\" ontsluit veel websites die nog in aanbouw zijn. Verscheidene versies hebben zich ontwikkeld in de loop van de jaren, soms per ongeluk soms expres (ingevoegde humor en dergelijke).', '2020-06-21 14:47:42', '2020-06-21 15:27:45'),
(3, 1, 1, '27', 'Skyrim', 'skyrim', 'Het is al geruime tijd een bekend gegeven dat een lezer, tijdens het bekijken van de layout van een pagina, afgeleid wordt door de tekstuele inhoud. Het belangrijke punt van het gebruik van Lorem Ipsum is dat het uit een min of meer normale verdeling van letters bestaat, in tegenstelling tot \"Hier uw tekst, hier uw tekst\" wat het tot min of meer leesbaar nederlands maakt. Veel desktop publishing pakketten en web pagina editors gebruiken tegenwoordig Lorem Ipsum als hun standaard model tekst, en een zoekopdracht naar \"lorem ipsum\" ontsluit veel websites die nog in aanbouw zijn. Verscheidene versies hebben zich ontwikkeld in de loop van de jaren, soms per ongeluk soms expres (ingevoegde humor en dergelijke).', '2020-06-21 15:32:13', '2020-06-21 15:32:13');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
CREATE TABLE IF NOT EXISTS `blog_categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Funko Pop', 'funko-pop', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(2, 'Actie Figuren', 'actie-figuren', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(3, 'Sleutelhangers', 'sleutelhangers', '2020-06-21 05:20:59', '2020-06-21 05:20:59');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Funko Pop', 'funko-pop', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(2, 'Actie Figuren', 'actie-figuren', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(3, 'Sleutelhangers', 'sleutelhangers', '2020-06-21 05:20:59', '2020-06-21 05:20:59');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordernumber` int(11) DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `currencies`
--

DROP TABLE IF EXISTS `currencies`;
CREATE TABLE IF NOT EXISTS `currencies` (
  `iso` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`iso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `currencies`
--

INSERT INTO `currencies` (`iso`, `created_at`, `updated_at`) VALUES
('EUR', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
('GBP', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
('USD', '2020-06-21 05:20:59', '2020-06-21 05:20:59');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `faqs`
--

DROP TABLE IF EXISTS `faqs`;
CREATE TABLE IF NOT EXISTS `faqs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `faq_category_id` int(11) NOT NULL,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `faq_categories`
--

DROP TABLE IF EXISTS `faq_categories`;
CREATE TABLE IF NOT EXISTS `faq_categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `faq_categories`
--

INSERT INTO `faq_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'BESTELLEN EN LEVEREN', 'bestellen en leveren', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(2, 'BETALEN', 'betalen', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(3, 'RETOURNEREN', 'retourneren', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(4, 'GARANTIE', 'garantie', '2020-06-21 05:20:59', '2020-06-21 05:20:59');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_05_05_081333_create_roles_table', 1),
(5, '2020_05_05_081401_create_addresses_table', 1),
(6, '2020_05_05_081416_create_blogs_table', 1),
(7, '2020_05_05_081455_create_blog_categories_table', 1),
(8, '2020_05_05_081521_create_categories_table', 1),
(9, '2020_05_05_081539_create_faqs_table', 1),
(10, '2020_05_05_081556_create_faq_categories_table', 1),
(11, '2020_05_05_081654_create_sub_categories_table', 1),
(12, '2020_05_06_091610_create_orders_table', 1),
(13, '2020_05_06_091628_create_stocks_table', 1),
(14, '2020_05_07_070950_create_products_table', 1),
(15, '2020_05_07_070951_create_reviews_table', 1),
(16, '2020_05_07_070956_create_photos_table', 1),
(17, '2020_05_22_130232_create_payment_platforms_table', 1),
(18, '2020_05_22_130259_create_currencies_table', 1),
(19, '2020_06_16_070447_create_contacts_table', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `total_price` decimal(8,2) NOT NULL,
  `payment_token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_price`, `payment_token`, `created_at`, `updated_at`) VALUES
(1, 2, '22.94', 'tok_1GwXi4GbSxfp9UeIbXIkiJtx', '2020-06-21 16:16:08', '2020-06-21 16:16:08'),
(2, 2, '12.94', 'tok_1GwXkdGbSxfp9UeIluvTpa21', '2020-06-21 16:18:46', '2020-06-21 16:18:46'),
(3, 1, '21.94', 'tok_1GwXsZGbSxfp9UeI9aVOCrDj', '2020-06-21 16:30:13', '2020-06-21 16:30:13'),
(4, 1, '22.94', 'tok_1GwXwpGbSxfp9UeITW5TQfh1', '2020-06-21 16:31:23', '2020-06-21 16:31:23'),
(5, 1, '21.94', 'tok_1GwXywGbSxfp9UeIKXknr4sf', '2020-06-21 16:33:33', '2020-06-21 16:33:33'),
(6, 1, '22.93', 'tok_1GwY04GbSxfp9UeI8NxtZfSl', '2020-06-21 16:40:59', '2020-06-21 16:40:59'),
(7, 1, '18.94', 'tok_1GwY7jGbSxfp9UeILyzZLS1d', '2020-06-21 16:42:39', '2020-06-21 16:42:39'),
(8, 1, '21.94', 'tok_1GwYHTGbSxfp9UeIblqghY5k', '2020-06-21 16:55:22', '2020-06-21 16:55:22'),
(9, 1, '20.94', 'tok_1GwYMTGbSxfp9UeIuDTCqNrD', '2020-06-21 17:04:10', '2020-06-21 17:04:10'),
(10, 1, '21.94', 'tok_1GwYUlGbSxfp9UeIFCipM9Dh', '2020-06-21 17:07:36', '2020-06-21 17:07:36'),
(11, 1, '21.94', 'tok_1GwYZFGbSxfp9UeIH7CZk0tv', '2020-06-21 17:11:05', '2020-06-21 17:11:05'),
(12, 1, '21.94', 'tok_1GwYw8GbSxfp9UeISajEUFIM', '2020-06-21 18:04:42', '2020-06-21 18:04:42');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `order_stock`
--

DROP TABLE IF EXISTS `order_stock`;
CREATE TABLE IF NOT EXISTS `order_stock` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `stock_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stock_id` (`order_id`),
  KEY `order_stock_stock_id_foreign` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `payment_platforms`
--

DROP TABLE IF EXISTS `payment_platforms`;
CREATE TABLE IF NOT EXISTS `payment_platforms` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `payment_platforms`
--

INSERT INTO `payment_platforms` (`id`, `name`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Paypal', 'images/paypalsmall.png', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(2, 'Stripe', 'images/Stripe.png', '2020-06-21 05:20:59', '2020-06-21 05:20:59');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `name`, `file`, `created_at`, `updated_at`) VALUES
(1, 'default-image', 'default-image.jpg', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(2, 'Mount_Lady_Duo', '1592725392Mount_Lady_Duo.jpg', '2020-06-21 05:43:12', '2020-06-21 05:43:12'),
(3, 'Wilma_Flintstone_Duo', '1592725566Wilma_Flintstone_Duo.jpg', '2020-06-21 05:46:06', '2020-06-21 05:46:06'),
(4, 'Stephen_Curry', '1592725672Stephen_Curry.jpg', '2020-06-21 05:47:52', '2020-06-21 05:47:52'),
(5, 'Rattata_Duo', '1592726078Rattata_Duo.jpg', '2020-06-21 05:54:38', '2020-06-21 05:54:38'),
(6, 'Mercy_Keyschain', '1592726163Mercy_Keyschain.png', '2020-06-21 05:56:03', '2020-06-21 05:56:03'),
(7, 'Captain_America_Duo', '1592726279Captain_America_Duo.png', '2020-06-21 05:57:59', '2020-06-21 05:57:59'),
(8, 'Venomized_Miles_Morales_Duo', '1592726343Venomized_Miles_Morales_Duo.jpg', '2020-06-21 05:59:03', '2020-06-21 05:59:03'),
(9, 'Harry_Potter_Duo', '1592726602Harry_Potter_Duo.jpg', '2020-06-21 06:03:22', '2020-06-21 06:03:22'),
(11, 'Shawn_Mendes_Duo', '1592727141Shawn_Mendes_Duo.jpg', '2020-06-21 06:12:21', '2020-06-21 06:12:21'),
(12, 'Jon_Snow_Keychain', '1592727199Jon_Snow_Keychain.png', '2020-06-21 06:13:19', '2020-06-21 06:13:19'),
(13, 'Sheriff_Woody_Keyschain', '1592727263Sheriff_Woody_Keyschain.png', '2020-06-21 06:14:23', '2020-06-21 06:14:23'),
(14, 'Scorpion.', '1592727481Scorpion.jpeg', '2020-06-21 06:18:01', '2020-06-21 06:18:01'),
(15, 'StarwarsFig.', '1592727567StarwarsFig.jpeg', '2020-06-21 06:19:27', '2020-06-21 06:19:27'),
(16, 'Ghostbuster.', '1592727700Ghostbuster.jpeg', '2020-06-21 06:21:40', '2020-06-21 06:21:40'),
(17, 'EYZU-brX0AAx4mR', '1592755241EYZU-brX0AAx4mR.jpg', '2020-06-21 14:00:41', '2020-06-21 14:00:41'),
(22, 'EYZOILMWsAAYDDK', '1592758085EYZOILMWsAAYDDK.jpg', '2020-06-21 14:48:05', '2020-06-21 14:48:05'),
(24, 'download', '1592758930download.jpg', '2020-06-21 15:02:10', '2020-06-21 15:02:10'),
(26, 'Steve_Irwin_Duo', '1592759805Steve_Irwin_Duo.jpg', '2020-06-21 15:16:45', '2020-06-21 15:16:45'),
(27, 'EY9NxDYX0AAmaWv', '1592760733EY9NxDYX0AAmaWv.jpg', '2020-06-21 15:32:13', '2020-06-21 15:32:13');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `photo_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `subcategory_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `subtitle` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_category_id_index` (`category_id`),
  KEY `products_subcategory_id_index` (`subcategory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `products`
--

INSERT INTO `products` (`id`, `photo_id`, `category_id`, `subcategory_id`, `name`, `title`, `slug`, `price`, `subtitle`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '2', 1, 10, 'Mount Lady', 'Mount Lady \'Animation Series\'', 'mount-lady-animation-series', '14.99', 'Pop Vinyl zijn ongeveer 9,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Mount Lady nu in de webshop, voeg haar toe tot uw collectie!', '2020-06-21 05:43:12', '2020-06-21 05:43:12', NULL),
(2, '3', 1, 10, 'Wilma', 'Wilma Flintstone \'Animation Serie\'', 'wilma-flintstone-animation-serie', '16.99', 'Pop Vinyl zijn ongeveer 9,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Wilma Flintstone in de webshop, voeg haar toe in uw collectie!', '2020-06-21 05:46:06', '2020-06-21 05:46:06', NULL),
(3, '4', 1, 4, 'Stephen Curry', 'Stephen Curry \'Basketbal Serie\'', 'stephen-curry-basketbal-serie', '14.99', 'Pop Vinyl zijn ongeveer 9,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Stephen Curry met basketbal in de hand nu in de webshop, voeg hem vandaag nog toe tot uw collectie!', '2020-06-21 05:47:52', '2020-06-21 05:47:52', NULL),
(4, '5', 1, 1, 'Rattata', 'Rattata \'Pokemon\' Games Serie', 'rattata-pokemon-games-serie', '12.99', 'Pop Vinyl zijn ongeveer 9,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Rattata Pokemon Muis, voeg toe aan je collectie!', '2020-06-21 05:54:38', '2020-06-21 05:54:38', NULL),
(5, '6', 3, 1, 'Mercy', 'Mercy Pocket pop! Sleutelhanger', 'mercy-pocket-pop-sleutelhanger', '8.99', 'Sleutelhangers', 'Mercy \'Overwatch\' Game sleutelhanger!', '2020-06-21 05:56:03', '2020-06-21 05:56:03', NULL),
(6, '7', 1, 9, 'Captain America', 'Captain America \'Marvel\'', 'captain-america-marvel', '15.99', 'Pop Vinyl zijn ongeveer 9,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Captain America \'Marvel\', voeg hem vandaag toe tot uw collectie!', '2020-06-21 05:57:59', '2020-06-21 05:57:59', NULL),
(7, '8', 1, 9, 'Miles Morales', 'Miles Morales \'Marvel\'', 'miles-morales-marvel', '16.99', 'Pop Vinyl zijn ongeveer 9,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Miles Morales \'Marvel\', voeg hem vandaag nog toe tot uw collectie!', '2020-06-21 05:59:03', '2020-06-21 05:59:03', NULL),
(8, '9', 1, 12, 'Harry Potter', 'Harry Potter \'Television Serie\'', 'harry-potter-television-serie', '15.99', 'Pop Vinyl zijn ongeveer 9,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Harry Potter the wizard, voeg hem vandaag toe tot je collectie!', '2020-06-21 06:03:22', '2020-06-21 06:03:22', NULL),
(9, '26', 1, 12, 'Steve Irwin', 'Steve Irwin \'Australia Zoo\'', 'steve-irwin-australia-zoo', '13.99', 'Pop Vinyl zijn ongeveer 9,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Steve Irwin \'Australia Zoo\', voeg hem vandaag nog toe tot uw collectie!', '2020-06-21 06:08:02', '2020-06-21 15:16:45', NULL),
(10, '11', 1, 3, 'Shawn Mendes', 'Shawn Mendes \'Music Serie\'', 'shawn-mendes-music-serie', '14.99', 'Pop Vinyl zijn ongeveer 9,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Shawn Mendes \'Music Serie\', voeg hem toe in uw collectie!', '2020-06-21 06:12:21', '2020-06-21 06:12:21', NULL),
(11, '12', 3, 11, 'Jon Snow', 'Jon Snow Pocket pop! Sleutelhanger', 'jon-snow-pocket-pop-sleutelhanger', '8.99', 'Jon Snow Pocket pop!', 'Jon Snow Pocket pop! Sleutelhanger', '2020-06-21 06:13:19', '2020-06-21 06:13:19', NULL),
(12, '13', 3, 6, 'Sheriff Woody', 'Sheriff Woody \'Toy Story\' Sleutelhanger!', 'sheriff-woody-toy-story-sleutelhanger', '9.99', 'Sheriff Woody \'Toy Story\' Sleutelhanger!', 'Sheriff Woody \'Toy Story\' Sleutelhanger!', '2020-06-21 06:14:23', '2020-06-21 06:14:23', NULL),
(13, '14', 2, 1, 'Scorpion', 'Scorpion \'Mortal Kombat\'', 'scorpion-mortal-kombat', '17.99', 'Aktie figuren zijn ongeveer 12,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Scorpion \'Mortal Kombat\'', '2020-06-21 06:18:01', '2020-06-21 06:18:01', NULL),
(14, '15', 2, 7, 'Stormtrooper', 'Stormtrooper \'Star Wars\'', 'stormtrooper-star-wars', '18.99', 'Aktie figuren zijn ongeveer 12,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Stormtrooper \'Star Wars\'', '2020-06-21 06:19:27', '2020-06-21 06:19:27', NULL),
(15, '16', 2, 2, 'Dr. Raymond Stantz', 'Dr. Raymond Stantz \'Ghostbusters\'', 'dr-raymond-stantz-ghostbusters', '17.99', 'Actie figuren zijn ongeveer 12,5 cm hoog. Komt verpakt in een mooi venster-display box.', 'Dr. Raymond Stantz \'Ghostbusters\'', '2020-06-21 06:21:40', '2020-06-21 06:21:40', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `reviews`
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_user_id_index` (`user_id`),
  KEY `reviews_product_id_index` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `product_id`, `email`, `rating`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 15, 'verhaegheangelino@gmail.com', 8, 'Een review op actie figuur, Ghostbusters!', '2020-06-21 12:57:41', '2020-06-21 12:57:41'),
(2, 1, 14, 'verhaegheangelino@gmail.com', 8, 'Review op StormTrooper! AV', '2020-06-21 13:11:15', '2020-06-21 13:11:15'),
(3, 2, 15, 'hupla@hupla.com', 7, 'Ghostbuster beoordeling van Paul!', '2020-06-21 15:40:31', '2020-06-21 15:40:31'),
(4, 2, 14, 'hupla@hupla.com', 7, 'Stormtrooper, beoordeling van Paul!', '2020-06-21 15:42:57', '2020-06-21 15:42:57');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(2, 'Buyer', '2020-06-21 05:20:59', '2020-06-21 05:20:59');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `stocks`
--

DROP TABLE IF EXISTS `stocks`;
CREATE TABLE IF NOT EXISTS `stocks` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `photo_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stocks_product_id_index` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `stocks`
--

INSERT INTO `stocks` (`id`, `photo_id`, `product_id`, `quantity`, `created_at`, `updated_at`) VALUES
(1, '26', 1, 20, '2020-06-21 05:43:12', '2020-06-21 05:43:12'),
(2, '26', 2, 20, '2020-06-21 05:46:06', '2020-06-21 05:46:06'),
(3, '26', 3, 20, '2020-06-21 05:47:52', '2020-06-21 05:47:52'),
(4, '26', 4, 20, '2020-06-21 05:54:38', '2020-06-21 05:54:38'),
(5, '26', 5, 20, '2020-06-21 05:56:03', '2020-06-21 05:56:03'),
(6, '26', 6, 20, '2020-06-21 05:57:59', '2020-06-21 05:57:59'),
(7, '26', 7, 20, '2020-06-21 05:59:03', '2020-06-21 05:59:03'),
(8, '26', 8, 20, '2020-06-21 06:03:22', '2020-06-21 06:03:22'),
(9, '26', 9, 20, '2020-06-21 06:08:02', '2020-06-21 06:08:02'),
(10, '26', 10, 20, '2020-06-21 06:12:21', '2020-06-21 06:12:21'),
(11, '26', 11, 20, '2020-06-21 06:13:19', '2020-06-21 06:13:19'),
(12, '26', 12, 20, '2020-06-21 06:14:23', '2020-06-21 06:14:23'),
(13, '26', 13, 20, '2020-06-21 06:18:01', '2020-06-21 06:18:01'),
(14, '26', 14, 20, '2020-06-21 06:19:27', '2020-06-21 06:19:27'),
(15, '26', 15, 20, '2020-06-21 06:21:40', '2020-06-21 06:21:40');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sub_categories`
--

DROP TABLE IF EXISTS `sub_categories`;
CREATE TABLE IF NOT EXISTS `sub_categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Games', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(2, 'Film', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(3, 'Muziek', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(4, 'Basketbal', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(5, 'Voetbal', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(6, 'Disney', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(7, 'Star Wars', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(8, 'WWE', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(9, 'Marvel', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(10, 'Animatie', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(11, 'Series', '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(12, 'Televisie', '2020-06-21 05:20:59', '2020-06-21 05:20:59');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `photo_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `address_id` bigint(20) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_address_id_index` (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `photo_id`, `address_id`, `name`, `password`, `email`, `email_verified_at`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '1', 1, 'Angelino Verhaeghe', '$2y$10$ZIhfyJhlcRebmfD1av/xqus4.uoGnpYEeuXrVHtYqSQ9SKxE5nxM.', 'verhaegheangelino@gmail.com', '2020-06-21 05:20:59', NULL, '2020-06-21 05:20:59', '2020-06-21 05:20:59', NULL),
(2, '24', 2, 'Paul Vermeersch', '$2y$10$.Wy/arbGPg/tdZsR8rwkPOlzv11nYRikoeasKx5tZhKCiK/TS9s72', 'hupla@hupla.com', NULL, NULL, '2020-06-21 15:00:40', '2020-06-21 15:02:10', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `user_role`
--

DROP TABLE IF EXISTS `user_role`;
CREATE TABLE IF NOT EXISTS `user_role` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_role_user_id_role_id_unique` (`user_id`,`role_id`),
  KEY `user_role_role_id_foreign` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `user_role`
--

INSERT INTO `user_role` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2020-06-21 05:20:59', '2020-06-21 05:20:59'),
(2, 2, 2, '2020-06-21 15:00:40', '2020-06-21 15:00:40');

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `contacts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Beperkingen voor tabel `order_stock`
--
ALTER TABLE `order_stock`
  ADD CONSTRAINT `order_stock_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_stock_stock_id_foreign` FOREIGN KEY (`stock_id`) REFERENCES `stocks` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `products_subcategory_id_foreign` FOREIGN KEY (`subcategory_id`) REFERENCES `sub_categories` (`id`);

--
-- Beperkingen voor tabel `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Beperkingen voor tabel `user_role`
--
ALTER TABLE `user_role`
  ADD CONSTRAINT `user_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_role_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
